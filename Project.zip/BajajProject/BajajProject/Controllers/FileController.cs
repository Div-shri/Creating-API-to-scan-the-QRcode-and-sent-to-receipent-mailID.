using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using QRCoder;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO;
using System.Net.Mail;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http.Extensions;

using System.Runtime.Intrinsics.X86;

namespace BajajProject.Controllers
{
    [ApiController]
    [Route("api/files")]
    public class FilesController : ControllerBase
    {
        private readonly string connectionString = "Host=localhost;Port=5432;Database=Testing;Username=postgres;Password=root";

        [HttpPost]
        public IActionResult UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file uploaded.");

            try
            {
                List<UserData> users = new List<UserData>();

                using (var reader = new StreamReader(file.OpenReadStream()))
                {
                    // Skip the first line (header)
                    reader.ReadLine();

                    while (reader.Peek() >= 0)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        var code = values[0];
                        var name = values[1];
                        var email = values[2];
                        var url = values[3];

                        // Generate QR code
                        string qrCodeImagePath = GenerateQrCode(code, name, url);

                        // Send email with QR code
                        SendEmailWithQrCode(email, qrCodeImagePath, code, name, url);

                        users.Add(new UserData
                        {
                            Code = code,
                            Name = name,
                            Email = email,
                            URL = url,
                            QrCodeImagePath = qrCodeImagePath
                        });
                    }
                }

                InsertUsersIntoDatabase(users);

                return Ok(new { Message = "File uploaded successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { ErrorMessage = $"Error uploading file: {ex.Message}" });
            }
        }

        private string GenerateQrCode(string code, string name, string url)
        {
            string combinedData = $"{url}"; // Combine code and URL

            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(combinedData, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);

            string directoryPath = @"E:\Asp.Net\BajajProject\QRCodeImages";
            if (!Directory.Exists(directoryPath))
                Directory.CreateDirectory(directoryPath);

            string fileName = $"{Guid.NewGuid()}.png";
            string qrCodeImagePath = Path.Combine(directoryPath, fileName);

            using (Bitmap qrCodeImage = qrCode.GetGraphic(20))
            {
                qrCodeImage.Save(qrCodeImagePath, ImageFormat.Png);
            }

            // Create a new image file with the redirection script appended to the QR code image
            string qrCodeImageWithRedirectPath = qrCodeImagePath.Replace(".png", "_redirect.png");
            using (Image qrCodeImageWithRedirect = Image.FromFile(qrCodeImagePath))
            using (Graphics graphics = Graphics.FromImage(qrCodeImageWithRedirect))
            {
                string redirectScript = $"<a href='{url}'></a>";
                graphics.DrawString(redirectScript, new Font(FontFamily.GenericSansSerif, 12), Brushes.Black, PointF.Empty);
                qrCodeImageWithRedirect.Save(qrCodeImageWithRedirectPath, ImageFormat.Png);
            }

            // Delete the original QR code image
           // File.Delete(qrCodeImagePath);

            return qrCodeImageWithRedirectPath;
        }



        private bool IsValidEmail(string email)
        {
            // Regular expression pattern for validating email addresses
            string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";

            // Check if the email address matches the pattern
            return Regex.IsMatch(email, pattern);
        }

        private void SendEmailWithQrCode(string email, string qrCodeImagePath, string code, string name, string url)
        {

            if (!IsValidEmail(email))
            {
                throw new ArgumentException("Invalid email address format.");
            }
            // Email configuration
            string senderEmail = "xx-xx-xx";
            string senderPassword = "xx-xx-xx";
            string smtpServer = "180.179.113.25";
            int smtpPort = 587;

            MailMessage mailMessage = new MailMessage(senderEmail, email);
            SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);

            // Create the email body
            mailMessage.Subject = "QR Code";
            // Create the email body with the URL
            mailMessage.Body = $"Hello {name},<br/><br/>Please find your QR code attached.<br/><br/>Code: {code}<br/>Name: {name}<br/>URL: {url}<br/><br/>Thank you.";

            mailMessage.IsBodyHtml = true;

            // Attach the QR code image
            Attachment qrCodeAttachment = new Attachment(qrCodeImagePath);
            mailMessage.Attachments.Add(qrCodeAttachment);

            // Send the email
            smtpClient.Credentials = new System.Net.NetworkCredential(senderEmail, senderPassword);
            smtpClient.EnableSsl = false;
            smtpClient.Send(mailMessage);
            smtpClient.UseDefaultCredentials = false;

            // Clean up resources
            mailMessage.Dispose();
            qrCodeAttachment.Dispose();
        }

        private void InsertUsersIntoDatabase(List<UserData> users)
        {
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                foreach (var user in users)
                {
                    // Update the URL to the redirected URL
                    user.URL = user.URL.Replace(".png", "_redirect.png");

                    // Fetch the URL from the table for comparison
                    string existingURL = GetExistingURLFromDatabase(user.Code);

                    // Check if the fetched URL is different from the current URL
                    // If different, update the current URL with the fetched URL
                    if (!string.IsNullOrEmpty(existingURL) && existingURL != user.URL)
                    {
                        user.URL = existingURL;
                    }

                    using (var command = new NpgsqlCommand("INSERT INTO Tiger (Code, Name, Email, URL, QrCodeImagePath) VALUES (@Code, @Name, @Email, @URL, @QrCodeImagePath)", connection))
                    {
                        command.Parameters.AddWithValue("Code", user.Code);
                        command.Parameters.AddWithValue("Name", user.Name);
                        command.Parameters.AddWithValue("Email", user.Email);
                        command.Parameters.AddWithValue("URL", user.URL);
                        command.Parameters.AddWithValue("QrCodeImagePath", user.QrCodeImagePath);
                        command.ExecuteNonQuery();
                    }
                }

                connection.Close();
            }
        }

        private string GetExistingURLFromDatabase(string code)
        {
            string existingURL = string.Empty;

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                using (var command = new NpgsqlCommand("SELECT URL FROM Tiger WHERE Code = @Code", connection))
                {
                    command.Parameters.AddWithValue("Code", code);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            existingURL = reader.GetString(0);
                        }
                    }
                }

                connection.Close();
            }

            return existingURL;
        }
    }

    public class UserData
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string URL { get; set; }
        public string QrCodeImagePath { get; set; }
    }
}
